
				<ul id="subnav">
						<li><a href="mng-users.php"><em>U</em>sers</a></li>
						<li><a href="mng-hs.php"><em>H</em>otspots</a></li>
						<li><a href="mng-rad-nas.php"><em>N</em>as</a></li>
                        <li><a href="mng-rad-usergroup.php"><em>U</em>ser-Groups</a></li>
                         <li><a href="mng-rad-profiles.php"><em>P</em>rofiles</a></li>
						<li><a href="mng-rad-groups.php"><em>G</em>roups</a></li>

						<li><a href="mng-rad-attributes.php"><em>A</em>ttributes</a></li>
						<li><a href="mng-rad-realms.php"><em>R</em>ealms/Proxys	</a></li>
						<li><a href="mng-rad-ippool.php"><em>I</em>P-Pool	</a></li>

<div id="logindiv" style="text-align: right;">

                                                <li>Location: <b><?php echo $_SESSION['location_name'] ?></b></li><br/>
						<li>Welcome, <?php echo $operator; ?></li>
						<li><a href="logout.php">[logout]</a></li>
				</ul>
		
		</div>
