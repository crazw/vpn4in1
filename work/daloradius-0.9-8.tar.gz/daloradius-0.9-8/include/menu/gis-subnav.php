
                                <ul id="subnav">

								<div id="logindiv" style="text-align: right;">
                                                <li>Location: <b><?php echo $_SESSION['location_name'] ?></b></li><br/>
                                                <li>Welcome, <?php echo $operator; ?></li>
                                                <li><a href="logout.php">[logout]</a></li>

                                </ul>
								
                </div>

